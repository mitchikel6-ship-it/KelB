package com.kelboard.app

import android.content.Context
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.inputmethodservice.InputMethodService
import android.media.AudioAttributes
import android.media.SoundPool
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.*
import android.widget.*

class KelBoardService : InputMethodService() {
    private lateinit var root: LinearLayout
    private var shift = false
    private var caps = false
    private var lastShift = 0L
    private var mode = 0 // 0 letters, 1 numbers, 2 emoji
    private val h = Handler(Looper.getMainLooper())
    private var popup: PopupWindow? = null
    private var sugg = listOf<TextView>()
    private val rows = arrayOf("qwertyuiop", "asdfghjkl", "zxcvbnm")
    private val dict = listOf("the", "to", "and", "of", "in", "is", "it", "you", "that", "for", "with", "was", "on", "are",
        "have", "this", "but", "not", "what", "hello", "how", "good", "thanks", "please", "love", "can", "just", "your",
        "about", "when", "where", "because", "going", "okay", "really", "tomorrow", "today", "morning", "night", "friend")

    private var sp: SoundPool? = null
    private var sounds = IntArray(3) // 0 letter, 1 delete, 2 modifier/space

    override fun onCreate() {
        super.onCreate()
        val pool = SoundPool.Builder().setMaxStreams(6)
            .setAudioAttributes(AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
            .build()
        sounds = intArrayOf(pool.load(this, R.raw.key_click, 1), pool.load(this, R.raw.key_delete, 1), pool.load(this, R.raw.key_mod, 1))
        sp = pool
    }

    override fun onDestroy() {
        sp?.release(); sp = null
        super.onDestroy()
    }

    private val dark get() = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
    private val bg get() = if (dark) 0xFF1B1B1D.toInt() else 0xFFD3D5DB.toInt()
    private val keyC get() = if (dark) 0xFF5C5C5F.toInt() else 0xFFFFFFFF.toInt()
    private val specC get() = if (dark) 0xFF3B3B3E.toInt() else 0xFFABB0BA.toInt()
    private val txt get() = if (dark) Color.WHITE else Color.BLACK
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun cp(n: Int) = String(Character.toChars(n))

    override fun onCreateInputView(): View {
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        render()
        return root
    }

    override fun onStartInputView(info: android.view.inputmethod.EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        mode = 0; caps = false
        shift = currentInputConnection?.getTextBeforeCursor(1, 0)?.isEmpty() ?: true
        if (::root.isInitialized) render()
    }

    override fun onConfigurationChanged(c: Configuration) {
        super.onConfigurationChanged(c)
        if (::root.isInitialized) render()
    }

    private fun render() {
        root.removeAllViews()
        root.setBackgroundColor(bg)
        root.setPadding(dp(3), dp(6), dp(3), dp(8))
        root.addView(suggestBar())
        when (mode) { 0 -> letters(); 1 -> numbers(); else -> emojiPanel() }
    }

    private fun suggestBar(): View {
        val bar = LinearLayout(this)
        val list = List(3) {
            TextView(this).apply {
                gravity = Gravity.CENTER; textSize = 17f; setTextColor(txt)
                layoutParams = LinearLayout.LayoutParams(0, dp(40), 1f)
                setOnClickListener { pick(text.toString()) }
            }
        }
        list.forEach { bar.addView(it) }
        sugg = list
        updateSuggestions()
        return bar
    }

    private fun prefixNow() = currentInputConnection?.getTextBeforeCursor(30, 0)?.toString()?.takeLastWhile { it.isLetter() } ?: ""

    private fun updateSuggestions() {
        val p = prefixNow()
        val out = if (p.isEmpty()) listOf("I", "The", "I'm") else {
            val m = dict.filter { it.startsWith(p.lowercase()) && it != p.lowercase() }
            listOf(m.getOrNull(0) ?: "", p, m.getOrNull(1) ?: "")
        }
        sugg.forEachIndexed { i, t -> t.text = out.getOrElse(i) { "" } }
    }

    private fun pick(word: String) {
        if (word.isEmpty()) return
        feedback()
        val ic = currentInputConnection ?: return
        val p = prefixNow()
        if (p.isNotEmpty()) ic.deleteSurroundingText(p.length, 0)
        ic.commitText("$word ", 1)
        updateSuggestions()
    }

    private fun feedback(kind: Int = 0) {
        sp?.play(sounds[kind], 1f, 1f, 1, 0, 1f)
        root.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
    }

    private fun key(label: String, w: Float, special: Boolean = false, pop: Boolean = false,
                    repeat: Boolean = false, onTap: () -> Unit): TextView {
        val t = TextView(this)
        val shape = GradientDrawable().apply { cornerRadius = dp(6).toFloat(); setColor(if (special) specC else keyC) }
        t.text = label; t.gravity = Gravity.CENTER
        t.textSize = if (label.length > 1) 16f else 22f
        t.setTextColor(txt); t.background = shape
        t.layoutParams = LinearLayout.LayoutParams(0, dp(46), w).apply { setMargins(dp(3), dp(5), dp(3), dp(5)) }
        var rep: Runnable? = null
        val kind = when { label == "\u232B" -> 1; special || label == "space" -> 2; else -> 0 }
        t.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    feedback(kind)
                    if (pop) showPop(v, label)
                    if (repeat) {
                        onTap()
                        val r = object : Runnable { override fun run() { onTap(); feedback(kind); h.postDelayed(this, 60) } }
                        rep = r; h.postDelayed(r, 400)
                    }
                }
                MotionEvent.ACTION_UP -> {
                    popup?.dismiss(); rep?.let { h.removeCallbacks(it) }
                    if (!repeat) onTap()
                }
                MotionEvent.ACTION_CANCEL -> { popup?.dismiss(); rep?.let { h.removeCallbacks(it) } }
            }
            true
        }
        return t
    }

    private fun showPop(v: View, s: String) {
        try {
            popup?.dismiss()
            val tv = TextView(this).apply {
                text = s; textSize = 34f; gravity = Gravity.CENTER; setTextColor(txt); elevation = dp(6).toFloat()
                background = GradientDrawable().apply { cornerRadius = dp(10).toFloat(); setColor(keyC) }
            }
            val hh = dp(70)
            val pw = v.width + dp(18)
            val p = PopupWindow(tv, pw, hh)
            p.isTouchable = false
            p.isClippingEnabled = false
            // position relative to the anchor key itself (not screen coords), clamped to the keyboard edges
            val loc = IntArray(2); v.getLocationInWindow(loc)
            val maxX = (v.rootView.width - pw - dp(2)).coerceAtLeast(dp(2))
            val targetX = (loc[0] - dp(9)).coerceIn(dp(2), maxX)
            val xoff = targetX - loc[0]
            val yoff = -v.height - hh + dp(4)
            p.showAsDropDown(v, xoff, yoff)
            popup = p
        } catch (_: Exception) {}
    }

    private fun row(vararg views: View) = LinearLayout(this).apply { views.forEach { addView(it) } }
    private fun spacer(w: Float) = View(this).apply { layoutParams = LinearLayout.LayoutParams(0, 1, w) }

    private fun type(s: String) {
        currentInputConnection?.commitText(s, 1)
        if (shift && !caps) { shift = false; h.post { render() } } else updateSuggestions()
    }

    private fun del() { sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL); updateSuggestions() }

    private fun enter() { if (!sendDefaultEditorAction(true)) sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER) }

    private fun toggleShift() {
        val now = SystemClock.uptimeMillis()
        if (now - lastShift < 350) { caps = true; shift = true }
        else if (caps) { caps = false; shift = false }
        else shift = !shift
        lastShift = now
        h.post { render() }
    }

    private fun letters() {
        fun up(c: Char) = if (shift || caps) c.uppercaseChar().toString() else c.toString()
        fun lk(c: Char) = key(up(c), 1f, pop = true) { type(up(c)) }
        root.addView(row(*rows[0].map { lk(it) }.toTypedArray()))
        root.addView(row(spacer(0.5f), *rows[1].map { lk(it) }.toTypedArray(), spacer(0.5f)))
        root.addView(row(
            key("\u21E7", 1.5f, special = !(shift || caps)) { toggleShift() },
            *rows[2].map { lk(it) }.toTypedArray(),
            key("\u232B", 1.5f, special = true, repeat = true) { del() }))
        root.addView(bottom())
    }

    private fun numbers() {
        fun nk(c: Char) = key(c.toString(), 1f, pop = true) { type(c.toString()) }
        root.addView(row(*"1234567890".map { nk(it) }.toTypedArray()))
        root.addView(row(*"-/:;()$&@\"".map { nk(it) }.toTypedArray()))
        root.addView(row(spacer(1.5f), *".,?!'".map { c -> key(c.toString(), 1.4f, pop = true) { type(c.toString()) } }.toTypedArray(),
            key("\u232B", 1.5f, special = true, repeat = true) { del() }))
        root.addView(bottom())
    }

    private fun bottom() = row(
        key(if (mode == 0) "123" else "ABC", 1.3f, special = true) { mode = if (mode == 0) 1 else 0; h.post { render() } },
        key(cp(0x1F642), 1f, special = true) { mode = 2; h.post { render() } },
        key("space", 4.4f) { type(" ") },
        key("return", 2f, special = true) { enter() })

    private fun emojiPanel() {
        val all = (0x1F600..0x1F64F).toList() + (0x1F446..0x1F450) + (0x1F493..0x1F49F) +
            listOf(0x2764, 0x1F525, 0x1F389, 0x1F4AF, 0x1F44D, 0x1F44E, 0x1F64F, 0x1F680, 0x2728, 0x1F31F)
        val grid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        all.chunked(8).forEach { chunk ->
            val r = LinearLayout(this)
            chunk.forEach { c ->
                r.addView(TextView(this).apply {
                    text = cp(c); textSize = 26f; gravity = Gravity.CENTER
                    layoutParams = LinearLayout.LayoutParams(0, dp(44), 1f)
                    setOnClickListener { feedback(); currentInputConnection?.commitText(cp(c), 1) }
                })
            }
            grid.addView(r)
        }
        val sv = ScrollView(this).apply { addView(grid) }
        root.addView(sv, LinearLayout.LayoutParams(-1, dp(190)))
        root.addView(row(key("ABC", 1.5f, special = true) { mode = 0; h.post { render() } }, spacer(7f),
            key("\u232B", 1.5f, special = true, repeat = true) { del() }))
    }
}
