package com.kelboard.app

import android.app.Activity
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.view.inputmethod.InputMethodManager
import android.widget.*

class MainActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val dark = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
        val fg = if (dark) Color.WHITE else Color.BLACK
        fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
        fun btn(label: String, onClick: () -> Unit) = Button(this).apply {
            text = label; isAllCaps = false; textSize = 17f; setTextColor(Color.WHITE)
            background = GradientDrawable().apply { cornerRadius = dp(14).toFloat(); setColor(0xFF0A84FF.toInt()) }
            layoutParams = LinearLayout.LayoutParams(-1, dp(54)).apply { topMargin = dp(14) }
            setOnClickListener { onClick() }
        }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(72), dp(24), dp(24))
            setBackgroundColor(if (dark) 0xFF111113.toInt() else 0xFFF2F2F7.toInt())
        }
        col.addView(TextView(this).apply { text = "KelBoard"; textSize = 38f; setTextColor(fg); setTypeface(null, Typeface.BOLD) })
        col.addView(TextView(this).apply { text = "An iOS-style keyboard for Android."; textSize = 16f; setTextColor(0xFF8E8E93.toInt()) })
        col.addView(btn("1. Enable KelBoard") { startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)) })
        col.addView(btn("2. Switch to KelBoard") { (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker() })
        col.addView(EditText(this).apply {
            hint = "3. Try typing here"; setTextColor(fg); setHintTextColor(0xFF8E8E93.toInt())
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(28) }
        })
        setContentView(col)
    }
}
